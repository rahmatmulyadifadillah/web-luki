import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Instagram, 
  MessageCircle, 
  ChevronDown, 
  Menu, 
  X, 
  ShoppingBag, 
  Star, 
  CheckCircle2, 
  Palette, 
  Ruler, 
  Type,
  Mail,
  MapPin,
  ArrowRight
} from 'lucide-react';

// --- Types ---
interface Product {
  id: string;
  name: string;
  price: string;
  type: 'bracelet' | 'keychain';
  images: string[];
  colors: string[];
  isBestSeller?: boolean;
}

// --- Components ---

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Beranda', href: '#hero' },
    { name: 'Gelang', href: '#gelang' },
    { name: 'Ganci', href: '#ganci' },
    { name: 'Custom', href: '#custom' },
    { name: 'Tentang', href: '#about' },
  ];

  return (
    <nav className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${scrolled ? 'bg-white/90 backdrop-blur-md shadow-sm py-3' : 'bg-transparent py-5'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <a href="#hero" className="flex items-center gap-2 group">
          <img src="/logo.jpeg" alt="Knotté" className="h-10 md:h-12 w-auto" />
          <span className="font-script text-3xl text-brand-olive font-bold tracking-tight">Knotté</span>
        </a>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center space-x-10">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className="text-sm font-medium text-brand-olive/80 hover:text-brand-brown transition-colors relative group"
            >
              {link.name}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-brand-brown transition-all duration-300 group-hover:w-full"></span>
            </a>
          ))}
          <button className="p-2 hover:bg-brand-peach/50 rounded-full transition-colors relative text-brand-olive">
            <ShoppingBag size={22} />
            <span className="absolute top-0 right-0 bg-brand-brown text-white text-[10px] w-4 h-4 flex items-center justify-center rounded-full">2</span>
          </button>
        </div>

        {/* Mobile Menu Button */}
        <div className="md:hidden flex items-center space-x-4">
           <button className="p-2 text-brand-olive">
            <ShoppingBag size={22} />
          </button>
          <button onClick={() => setIsOpen(!isOpen)} className="p-2 text-brand-olive">
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-full left-0 w-full bg-white border-t border-brand-blue p-6 md:hidden shadow-xl"
          >
            <div className="flex flex-col space-y-4">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href} 
                  onClick={() => setIsOpen(false)}
                  className="text-lg font-medium py-2 border-b border-gray-50"
                  id={`nav-link-mobile-${link.name}`}
                >
                  {link.name}
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const ProductCard = ({ product }: { product: Product; key?: string }) => {
  const orderViaWhatsApp = (productName: string) => {
    const phone = "6287801005291"; // Ganti dengan nomor asli
    const message = encodeURIComponent(`Halo Knotté, saya tertarik untuk memesan ${productName}. Mohon informasi lebih lanjut.`);
    window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
  };

  return (
    <motion.div 
      whileHover={{ y: -10 }}
      className="group relative card-premium flex flex-col h-full"
    >
      {product.isBestSeller && (
        <div className="absolute top-4 left-4 z-10 bg-white/90 text-brand-accent text-xs px-3 py-1 rounded-full backdrop-blur-md flex items-center gap-1 shadow-sm font-bold">
          <Star size={10} fill="currentColor" /> Best Seller
        </div>
      )}
      
      {/* 2 Product Images Layout */}
      <div className="grid grid-cols-2 gap-2 p-2 h-64">
        {product.images.slice(0, 2).map((img, idx) => (
          <div key={idx} className="overflow-hidden relative rounded-[14px] h-full">
            <img 
              src={img} 
              alt={`${product.name} variant ${idx + 1}`} 
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-brand-accent/5 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
        ))}
      </div>

      <div className="p-6 pt-2 flex-grow">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-serif text-xl text-brand-ink">{product.name}</h3>
          <span className="text-brand-accent font-bold">{product.price}</span>
        </div>
        
        <div className="mb-6">
          <p className="text-[10px] text-gray-500 uppercase tracking-widest font-bold mb-2">Pilihan Warna:</p>
          <div className="flex flex-wrap gap-1.5">
            {product.colors.map((color, i) => (
              <span key={i} className="text-[10px] text-brand-brown bg-brand-peach/30 px-2 py-0.5 rounded-full border border-brand-peach/50 font-medium">
                {color}
              </span>
            ))}
          </div>
        </div>

        <button 
          onClick={() => orderViaWhatsApp(product.name)}
          className="w-full py-3 bg-brand-cream hover:bg-brand-olive hover:text-white rounded-2xl text-sm font-semibold transition-all duration-300 flex items-center justify-center gap-2 group/btn border border-brand-peach"
        >
          Pesan Sekarang
          <ArrowRight size={16} className="transition-transform group-hover/btn:translate-x-1" />
        </button>
      </div>
    </motion.div>
  );
};

  const FAQAccordion = () => {
    const faqs = [
      { q: "Bagaimana cara custom aksesoris?", a: "Kamu bisa klik tombol 'Custom via WhatsApp' dan kirimkan referensi warna atau desain yang kamu inginkan untuk gelang maupun gantungan kunci. Tim kami akan membantumu memilih kombinasi beads yang pas!" },
      { q: "Berapa lama pengiriman?", a: "Proses pembuatan handmade biasanya 1-2 hari kerja. Pengiriman tergantung lokasi kamu, estimasi 2-4 hari kerja." },
      { q: "Material apa yang digunakan?", a: "Kami menggunakan premium glass beads, shell mother of pearl, mutiara sintetis, dan high-quality strings yang kuat serta tahan lama." },
      { q: "Apakah bisa retur?", a: "Retur berlaku jika barang rusak atau salah kirim, wajib menyertakan video unboxing maksimal 24 jam setelah paket diterima." },
      { q: "Metode pembayaran?", a: "Kami menerima Transfer Bank (BCA, Mandiri), E-Wallet (OVO, Dana, ShopeePay), dan QRIS melalui konfirmasi admin." },
    ];

  const [active, setActive] = useState<number | null>(null);

  return (
    <div className="max-w-3xl mx-auto space-y-4">
      {faqs.map((faq, i) => (
        <div key={i} className="bg-white rounded-3xl overflow-hidden border border-brand-blue/30 shadow-sm">
          <button 
            onClick={() => setActive(active === i ? null : i)}
            className="w-full px-8 py-5 flex justify-between items-center text-left hover:bg-gray-50/50 transition-colors"
          >
            <span className="font-medium text-gray-700">{faq.q}</span>
            <ChevronDown className={`transition-transform duration-300 ${active === i ? 'rotate-180' : ''}`} size={20} />
          </button>
          <AnimatePresence>
            {active === i && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <div className="px-8 pb-5 text-gray-500 leading-relaxed text-sm">
                  {faq.a}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      ))}
    </div>
  );
};

export default function App() {
  const products: Product[] = [
    {
      id: '1',
      name: 'Gelang Mutiara',
      price: 'Rp6.000',
      type: 'bracelet',
      images: [
        'gelang mutiara 1.jpeg',
        'gelang mutiara 2.jpeg'
      ],
      colors: ['Putih Silver', 'Baby Blue', 'Cream', 'Pink Pastel', 'Biru Langit'],
      isBestSeller: true
    },
    {
      id: '2',
      name: 'Gelang Kerang',
      price: 'Rp10.000',
      type: 'bracelet',
      images: [
        'gelang kerang 1.jpeg',
        'gelang kerang 2.jpeg'
      ],
      colors: ['Cream Coklat', 'Biru Putih', 'Beige', 'Silver Blue', 'Pink Soft']
    },
    {
      id: '3',
      name: 'Gelang Bunga',
      price: 'Rp8.000',
      type: 'bracelet',
      images: [
        'gelang bunga 1.jpeg',
        'gelang bunga 2.jpeg'
      ],
      colors: ['Pink Putih', 'Biru Silver', 'Lavender', 'Cream', 'Baby Blue'],
      isBestSeller: true
    }
  ];

  const ganciItems = [
    { color: 'Coklat', img: 'gunci cream.jpeg' },
    { color: 'Pink', img: 'gunci pink.jpeg' }
  ];

  return (
    <div className="min-h-screen">
      <Navbar />

      {/* --- Floating Button --- */}
      <motion.a
        href={`https://wa.me/62878010005291?text=${encodeURIComponent("Halo Knotté, saya ingin menanyakan koleksi aksesoris terbaru.")}`}
        target="_blank"
        rel="noopener noreferrer"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        whileHover={{ scale: 1.1 }}
        className="fixed bottom-6 right-6 z-[60] bg-[#25D366] text-white p-4 rounded-full shadow-2xl shadow-[#25D366]/40 flex items-center justify-center"
      >
        <MessageCircle size={28} />
      </motion.a>

      {/* --- HERO SECTION --- */}
      <section id="hero" className="relative min-h-screen flex items-center pt-20 overflow-hidden bg-brand-cream">
        <div className="absolute top-0 right-0 w-[60%] h-full bg-brand-peach/40 rounded-l-[10rem] -z-10 translate-x-[20%]"></div>
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <h1 className="font-serif text-6xl md:text-8xl text-brand-olive leading-tight mb-6">
              Buat Aksesoris <br />
              <span className="text-brand-brown font-script font-normal lowercase text-5xl md:text-7xl">Handmade with warmth</span>
            </h1>
            <p className="text-lg text-gray-500 mb-10 max-w-md leading-relaxed">
              Gelang handmade aesthetic dan gantungan kunci lucu dengan desain feminin dan warna yang cantik.
            </p>
            <div className="flex flex-wrap gap-4">
              <a href="#gelang" className="btn-primary" id="cta-shop">Belanja Sekarang</a>
              <a href="#custom" className="btn-secondary" id="cta-custom">Custom</a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="relative"
          >
            <div className="relative z-10 w-full aspect-square rounded-[32px] overflow-hidden shadow-3xl shadow-brand-baby/50 rotate-3 hover:rotate-0 transition-transform duration-700 bg-white flex items-center justify-center p-8">
              <img 
                src="/logo_knott_logo.png" 
                alt="Knotté Logo" 
                className="w-full h-auto object-contain"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="absolute -bottom-10 -left-10 w-48 h-48 bg-brand-baby/50 rounded-full blur-3xl -z-10"></div>
            <div className="absolute top-1/2 -right-12 w-24 h-24 glass-card rounded-3xl p-4 flex flex-col items-center justify-center">
              <span className="text-xs text-brand-accent font-bold">100%</span>
              <span className="text-[10px] text-center text-brand-ink">Handmade Love</span>
            </div>
          </motion.div>
        </div>
      </section>

      {/* --- PROMO BANNER --- */}
      <section className="py-12 bg-gradient-to-r from-brand-olive to-brand-brown text-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 flex flex-wrap justify-center md:justify-between items-center gap-8">
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
               <span className="text-lg">✨</span>
             </div>
             <span className="font-semibold">Gratis Packaging Lucu</span>
          </div>
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
               <span className="text-lg">🌿</span>
             </div>
             <span className="font-semibold capitalize">Handmade with Warmth</span>
          </div>
          <div className="flex items-center gap-3">
             <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
               <span className="text-lg">🏷️</span>
             </div>
             <span className="font-semibold">Diskon Spesial Hari Ini</span>
          </div>
        </div>
      </section>

      {/* --- GELANG SECTION --- */}
      <section id="gelang" className="py-24 bg-brand-cream/50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl text-brand-olive mb-4">Koleksi Gelang Terfavorit</h2>
            <p className="text-gray-400">Pilih aksesoris yang paling cocok dengan gaya aesthetic-mu</p>
          </div>
          <div className="grid md:grid-cols-3 gap-10">
            {products.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* --- GANCI SECTION --- */}
      <section id="ganci" className="py-24 bg-brand-peach/10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
            <div>
               <h2 className="font-serif text-4xl text-brand-olive mb-4 italic">Ganci Aesthetic Collection</h2>
               <p className="text-gray-400">Tampilan manis untuk tas atau kunci favoritmu</p>
            </div>
            <span className="text-2xl font-serif text-brand-brown">Harga: Rp10.000</span>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {ganciItems.map((item, i) => (
              <div key={i} className="group relative overflow-hidden rounded-[32px] bg-white p-4 card-premium">
                <div className="aspect-[4/3] rounded-[24px] overflow-hidden mb-6 relative">
                   <img src={item.img} alt={`Ganci ${item.color}`} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                   {item.isCustom && (
                     <div className="absolute top-4 right-4 bg-white/90 text-brand-accent text-[10px] px-3 py-1 rounded-full backdrop-blur-md flex items-center gap-1 shadow-sm font-bold uppercase tracking-wider">
                       <Palette size={10} /> Custom
                     </div>
                   )}
                </div>
                <div className="px-4 mb-4">
                  <h4 className="font-serif text-2xl text-brand-olive mb-1">
                    {item.isCustom ? 'Gantungan Kunci Custom' : 'Aesthetic Charm'}
                  </h4>
                  <p className="text-sm text-brand-brown font-bold mb-4">Harga: {item.price || 'Rp10.000'}</p>
                  
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-gray-500 uppercase tracking-widest font-bold">Warna Produk:</span>
                      <span className="text-[10px] text-brand-olive/70 bg-brand-peach/30 px-3 py-1 rounded-full border border-brand-peach/50 font-semibold">
                        {item.isCustom ? 'Bebas Pilih Warna' : item.color}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-gray-500 uppercase tracking-widest font-bold">Tipe:</span>
                      <div className="flex gap-1.5 flex-wrap">
                        {item.isCustom ? (
                          <>
                            <span className="text-[10px] text-brand-brown/60 border border-brand-peach px-2 py-0.5 rounded-full italic">Nama</span>
                            <span className="text-[10px] text-brand-brown/60 border border-brand-peach px-2 py-0.5 rounded-full italic">Bunga</span>
                            <span className="text-[10px] text-brand-brown/60 border border-brand-peach px-2 py-0.5 rounded-full italic">Karakter</span>
                          </>
                        ) : (
                          <>
                            <span className="text-[10px] text-brand-brown/60 border border-brand-peach px-2 py-0.5 rounded-full italic">Cream</span>
                            <span className="text-[10px] text-brand-brown/60 border border-brand-peach px-2 py-0.5 rounded-full italic">Hitam</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>

                  <button 
                    onClick={() => {
                      const phone = "6287801005291";
                      const itemName = item.isCustom ? 'Gantungan Kunci Custom' : `Ganci Aesthetic - ${item.color}`;
                      const message = encodeURIComponent(`Halo Knotté, saya tertarik untuk memesan ${itemName}. Mohon informasi lebih lanjut.`);
                      window.open(`https://wa.me/${phone}?text=${message}`, '_blank');
                    }}
                    className="w-full btn-primary py-2 px-6 text-sm"
                  >
                    {item.isCustom ? 'Custom Sekarang' : 'Pesan'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* --- CUSTOM SECTION --- */}
      <section id="custom" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="bg-gradient-to-br from-brand-peach/20 to-white rounded-[32px] p-8 md:p-16 flex flex-col md:flex-row items-center gap-12 border border-brand-peach/50">
            <div className="md:w-1/2">
              <h2 className="font-serif text-5xl text-brand-olive mb-6">Custom Aksesoris <br />Sesuai Gayamu</h2>
              <p className="text-gray-400 mb-8 leading-relaxed">
                Ekspresikan kepribadianmu dengan gelang atau gantungan kunci yang dirancang khusus hanya untukmu. Kami melayani berbagai request spesial.
              </p>
              
              <ul className="space-y-4 mb-10">
                <li className="flex items-center gap-3">
                  <Palette className="text-brand-brown" size={20} />
                  <span className="text-brand-olive font-semibold">Bebas pilih warna & kombinasi beads</span>
                </li>
                <li className="flex items-center gap-3">
                  <Ruler className="text-brand-brown" size={20} />
                  <span className="text-brand-olive font-semibold">Ukuran disesuaikan (untuk gelang)</span>
                </li>
                <li className="flex items-center gap-3">
                  <Star className="text-brand-brown" size={20} />
                  <span className="text-brand-olive font-semibold">Custom Ganci: Bebas pilih warna</span>
                </li>
              </ul>
              
              <a 
                href={`https://wa.me/6287801005291?text=${encodeURIComponent("Halo Knotté, saya ingin melakukan pemesanan custom aksesoris (gelang/ganci) dengan desain sendiri.")}`}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary inline-flex items-center gap-3"
              >
                <MessageCircle size={20} /> Custom via WhatsApp
              </a>
            </div>
            <div className="md:w-1/2 grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <img src="gelang bunga 1.jpeg" className="rounded-[24px] shadow-lg shadow-brand-baby/20" alt="Custom 1" referrerPolicy="no-referrer" />
                <img src="gelang kerang 1.jpeg" className="rounded-[32px] shadow-lg shadow-brand-baby/20" alt="Custom 2" referrerPolicy="no-referrer" />
              </div>
              <div className="space-y-4 pt-8">
                <img src="gelang mutiara 1.jpeg" className="rounded-[32px] shadow-lg shadow-brand-baby/20" alt="Custom 3" referrerPolicy="no-referrer" />
                <img src="gunci pink.jpeg" className="rounded-[24px] shadow-lg shadow-brand-baby/20" alt="Custom 4" referrerPolicy="no-referrer" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* --- ABOUT BRAND --- */}
      <section id="about" className="py-24 bg-brand-peach/10">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h2 className="font-serif text-3xl text-brand-olive mb-8 tracking-widest uppercase font-semibold">About Knotté</h2>
          <p className="font-serif text-3xl md:text-5xl text-brand-brown leading-relaxed italic">
            “Knotté menghadirkan aksesoris handmade aesthetic dengan desain feminin dan elegan untuk menemani gaya dan momen spesialmu.”
          </p>
          <div className="mt-12 flex justify-center gap-4">
             <div className="w-12 h-[1px] bg-brand-olive mt-3 opacity-30"></div>
             <div className="flex items-center gap-2 text-brand-olive font-bold uppercase tracking-widest text-xs">
                <CheckCircle2 size={16} /> Certified Handmade
             </div>
             <div className="w-12 h-[1px] bg-brand-olive mt-3 opacity-30"></div>
          </div>
        </div>
      </section>

      {/* --- FAQ SECTION --- */}
      <section className="py-24 bg-brand-cream">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="font-serif text-4xl text-brand-olive">Frequently Asked Questions</h2>
          </div>
          <FAQAccordion />
        </div>
      </section>

      {/* --- FOOTER --- */}
      <footer className="pt-24 pb-12 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-12 pb-16 border-b border-brand-peach/30">
            <div className="col-span-2">
              <div className="flex items-center gap-2 mb-6">
                <img src="/logo_knott_logo.png" alt="Knotté" className="h-10 w-auto" />
                <h2 className="font-script text-4xl font-bold text-brand-olive tracking-tight">Knotté</h2>
              </div>
              <p className="text-gray-400 max-w-sm mb-6 leading-relaxed">
                Menciptakan keindahan dalam setiap simpul. Knotté menghadirkan aksesoris yang menceritakan gaya unikmu.
              </p>
              <div className="flex gap-4">
                <motion.a 
                  whileHover={{ y: -5 }} 
                  href="https://instagram.com/luxe.alesttri/" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full border border-brand-peach flex items-center justify-center text-brand-olive hover:text-brand-brown hover:border-brand-brown transition-all group"
                >
                   <Instagram size={18} />
                </motion.a>
                <motion.a 
                  whileHover={{ y: -5 }} 
                  href="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3945.143714652233!2d116.08832047501314!3d-8.583344691471783!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dcdbf69600e12d5%3A0x6331a69076f8e70b!2sUniversitas%20Teknologi%20Mataram%20(UTM)!5e0!3m2!1sid!2sid!4v1714631235000!5m2!1sid!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgradehttps://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3945.143714652233!2d116.08832047501314!3d-8.583344691471783!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dcdbf69600e12d5%3A0x6331a69076f8e70b!2sUniversitas%20Teknologi%20Mataram%20(UTM)!5e0!3m2!1sid!2sid!4v1714631235000!5m2!1sid!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full border border-brand-peach flex items-center justify-center text-brand-olive hover:text-brand-brown hover:border-brand-brown transition-all"
                >
                   <MapPin size={18} />
                </motion.a>
                <motion.a 
                  whileHover={{ y: -5 }} 
                  href={`https://wa.me/6287801005291?text=${encodeURIComponent("Halo Knotté, saya ingin bertanya tentang produk Anda.")}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 rounded-full border border-brand-peach flex items-center justify-center text-brand-olive hover:text-brand-brown hover:border-brand-brown transition-all"
                >
                   <MessageCircle size={18} />
                </motion.a>
              </div>
            </div>
            
            <div>
              <h4 className="font-bold text-brand-olive mb-6 uppercase text-xs tracking-widest">Contact Us</h4>
              <ul className="space-y-4 text-gray-500 text-sm">
                <li>
                   <a href="https://instagram.com/luxe.alesttri/" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-brand-brown transition-colors">
                    <Instagram size={14} /> @knotte.id
                   </a>
                </li>
                <li>
                   <a href={`https://wa.me/6287801005291?text=${encodeURIComponent("Halo Knotté, saya ingin memesan produk.")}`} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-brand-brown font-semibold hover:opacity-80 transition-opacity">
                    <MessageCircle size={14} /> +62 800-0000-0000
                   </a>
                </li>
                <li>
                   <a href="mailto:luckya lestari@luckyalestari05.com" className="flex items-center gap-2 hover:text-brand-brown transition-colors">
                    <Mail size={14} /> hello@knotte.com
                   </a>
                </li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold text-brand-olive mb-6 uppercase text-xs tracking-widest">Help</h4>
              <ul className="space-y-4 text-gray-500 text-sm font-medium">
                <li><a href="#" className="hover:text-brand-brown transition-colors">Cara Pemesanan</a></li>
                <li><a href="#" className="hover:text-brand-brown transition-colors">Pengiriman</a></li>
                <li><a href="#" className="hover:text-brand-brown transition-colors">Kebijakan Retur</a></li>
              </ul>
            </div>
          </div>
          
          <div className="pt-8 flex flex-col md:flex-row justify-between items-center text-[10px] text-gray-300 uppercase tracking-widest gap-4 font-bold">
             <p>© 2026 Knotté. All Rights Reserved.</p>
             <div className="flex gap-8">
                <a href="#" className="hover:text-brand-brown transition-colors">Privacy Policy</a>
                <a href="#" className="hover:text-brand-brown transition-colors">Terms of Service</a>
             </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
